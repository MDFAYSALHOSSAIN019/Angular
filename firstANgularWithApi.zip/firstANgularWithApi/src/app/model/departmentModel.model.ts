

export class DepartmentModel{

    id?: number;
    dname?: string;

}